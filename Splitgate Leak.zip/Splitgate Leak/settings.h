namespace Settings
{
	bool Aimbot = true;
	bool AimbotFOV = true;

	float AimbotRadius = 200.f;
	float Smoothing = 1.f;

	bool BoxESP = true;
	bool CornerESP = false;

	bool NameESP = true;
	bool DistanceESP = true;
	bool Skeletons = true;

	bool RapidFire = false;
	bool NoSpread = false;

	bool Watermark = true;
	bool Menu = true;
	bool Features_Enabled = true;

	bool FOV_Slider = false;
	bool Allow_Smoothing = false;
	bool Crosshair = true;

	float FOV_Amount = 80.f;
}