# Splitgate-Internal

- This is outdated
- Update Actor Loop
- Update Signatures/Offsets
- Add Offsets needed
- this uses steam hook


- ive left cheating community this is why i leaked this
